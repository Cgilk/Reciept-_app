import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:star_prnt/star_prnt.dart';

void main() => runApp(const ReceiptApp());

class ReceiptApp extends StatelessWidget {
  const ReceiptApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: ReceiptForm(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ReceiptForm extends StatefulWidget {
  const ReceiptForm({super.key});

  @override
  State<ReceiptForm> createState() => _ReceiptFormState();
}

class _ReceiptFormState extends State<ReceiptForm> {
  final customerController = TextEditingController();
  final itemController = TextEditingController();
  final priceController = TextEditingController();
  final headerController = TextEditingController(text: 'Sales Receipt');
  final footerController = TextEditingController(text: 'Thank you for your purchase!');
  final taxController = TextEditingController(text: '0');
  final shippingController = TextEditingController(text: '0');

  List<Map<String, dynamic>> items = [];
  Uint8List? logoBytes;
  List<Map<String, String>> savedTemplates = [];
  List<PortInfo> availablePorts = [];
  String? selectedPort;

  void addItem() {
    setState(() {
      items.add({
        'name': itemController.text,
        'price': double.tryParse(priceController.text) ?? 0.0,
      });
      itemController.clear();
      priceController.clear();
    });
  }

  Future<void> pickLogo() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      setState(() {
        logoBytes = bytes;
      });
    }
  }

  void saveTemplate() {
    setState(() {
      savedTemplates.add({
        'header': headerController.text,
        'footer': footerController.text,
      });
    });
  }

  void loadTemplate(Map<String, String> template) {
    setState(() {
      headerController.text = template['header'] ?? '';
      footerController.text = template['footer'] ?? '';
    });
  }

  Future<void> discoverPrinters() async {
    final ports = await StarPrnt.portDiscovery(PrinterType.usb);
    setState(() {
      availablePorts = ports;
      selectedPort = ports.isNotEmpty ? ports.first.portName : null;
    });
  }

  Future<void> printToTSP100() async {
    if (selectedPort == null) return;

    final commands = <List<int>>[];

    if (logoBytes != null) {
      final logo = await StarPrnt.imageRaster(logoBytes!);
      commands.addAll(logo);
    }

    commands.addAll(await StarPrnt.text('${headerController.text}\n\n'));
    commands.addAll(await StarPrnt.text('Customer: ${customerController.text}\n'));
    commands.addAll(await StarPrnt.text('\n'));

    for (var item in items) {
      commands.addAll(await StarPrnt.text('${item['name']} - \$${item['price'].toStringAsFixed(2)}\n'));
    }

    double subtotal = items.fold(0.0, (sum, item) => sum + item['price']);
    double tax = double.tryParse(taxController.text) ?? 0.0;
    double shipping = double.tryParse(shippingController.text) ?? 0.0;
    double total = subtotal + tax + shipping;

    commands.addAll(await StarPrnt.text('\nSubtotal: \$${subtotal.toStringAsFixed(2)}\n'));
    commands.addAll(await StarPrnt.text('Tax: \$${tax.toStringAsFixed(2)}\n'));
    commands.addAll(await StarPrnt.text('Shipping: \$${shipping.toStringAsFixed(2)}\n'));
    commands.addAll(await StarPrnt.text('Total: \$${total.toStringAsFixed(2)}\n'));

    commands.addAll(await StarPrnt.text('\n${footerController.text}\n'));
    commands.addAll(await StarPrnt.feed(2));
    commands.addAll(await StarPrnt.cutPaper());

    await StarPrnt.print(selectedPort!, {}, commands);
  }

  void generatePdf() async {
    final pdf = pw.Document();

    final total = items.fold(0.0, (sum, item) => sum + item['price']);
    final tax = double.tryParse(taxController.text) ?? 0.0;
    final shipping = double.tryParse(shippingController.text) ?? 0.0;
    final grandTotal = total + tax + shipping;

    final logoImage = logoBytes != null ? pw.MemoryImage(logoBytes!) : null;

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              if (logoImage != null) pw.Image(logoImage, height: 80),
              pw.SizedBox(height: 10),
              pw.Text(headerController.text, style: pw.TextStyle(fontSize: 24)),
              pw.SizedBox(height: 10),
              pw.Text('Customer: ${customerController.text}'),
              pw.SizedBox(height: 20),
              pw.Table.fromTextArray(
                headers: ['Item', 'Price'],
                data: items.map((item) => [item['name'], '\$${item['price'].toStringAsFixed(2)}']).toList(),
              ),
              pw.Divider(),
              pw.Text('Subtotal: \$${total.toStringAsFixed(2)}'),
              pw.Text('Tax: \$${tax.toStringAsFixed(2)}'),
              pw.Text('Shipping: \$${shipping.toStringAsFixed(2)}'),
              pw.Text('Total: \$${grandTotal.toStringAsFixed(2)}'),
              pw.SizedBox(height: 20),
              pw.Text(footerController.text, style: pw.TextStyle(fontStyle: pw.FontStyle.italic)),
            ],
          );
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  @override
  void initState() {
    super.initState();
    discoverPrinters();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Custom Receipt Maker')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: headerController,
              decoration: const InputDecoration(labelText: 'Receipt Header'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: customerController,
              decoration: const InputDecoration(labelText: 'Customer Name'),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: pickLogo,
              child: const Text('Upload Logo'),
            ),
            if (logoBytes != null)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Image.memory(logoBytes!, height: 60),
              ),
            const SizedBox(height: 16),
            TextField(
              controller: itemController,
              decoration: const InputDecoration(labelText: 'Item Name'),
            ),
            TextField(
              controller: priceController,
              decoration: const InputDecoration(labelText: 'Item Price'),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: addItem,
              child: const Text('Add Item'),
            ),
            const SizedBox(height: 20),
            const Text('Items:', style: TextStyle(fontWeight: FontWeight.bold)),
            for (var item in items)
              ListTile(
                title: Text(item['name']),
                trailing: Text('\$${item['price'].toStringAsFixed(2)}'),
              ),
            const SizedBox(height: 16),
            TextField(
              controller: taxController,
              decoration: const InputDecoration(labelText: 'Tax'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: shippingController,
              decoration: const InputDecoration(labelText: 'Shipping'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: footerController,
              decoration: const InputDecoration(labelText: 'Receipt Footer'),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: saveTemplate,
                  child: const Text('Save Template'),
                ),
                DropdownButton<Map<String, String>>(
                  hint: const Text('Load Template'),
                  items: savedTemplates.map((template) {
                    return DropdownMenuItem(
                      value: template,
                      child: Text(template['header'] ?? ''),
                    );
                  }).toList(),
                  onChanged: (template) {
                    if (template != null) loadTemplate(template);
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            DropdownButton<String>(
              hint: const Text('Select Printer'),
              value: selectedPort,
              items: availablePorts.map((port) => DropdownMenuItem(
                value: port.portName,
                child: Text(port.portName),
              )).toList(),
              onChanged: (value) => setState(() => selectedPort = value),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: generatePdf,
              child: const Text('Generate Receipt PDF'),
            ),
            ElevatedButton(
              onPressed: printToTSP100,
              child: const Text('Print to TSP100'),
            ),
          ],
        ),
      ),
    );
  }
}