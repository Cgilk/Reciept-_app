# Receipt App

A Flutter-based custom receipt maker with:
- Editable receipt header and footer
- Itemized entry with dynamic totals (tax, shipping)
- Logo upload support
- Template saving and loading
- PDF receipt generation
- TSP100 printer support (via StarPRNT plugin)

## Features
- 🖨 Print to Star Micronics TSP100 printer (USB)
- 🖼 Upload and display custom business logos
- 🧾 Save and reuse receipt templates
- 📄 Export receipts as printable PDFs

## Getting Started

### Requirements
- Flutter SDK
- Android Studio or VS Code
- USB-connected Star TSP100 printer (optional)

### Run the App
```bash
flutter pub get
flutter run
```

### Build APK
```bash
flutter build apk --debug
```

### StarPRNT Setup
Make sure your TSP100 printer is connected via USB and accessible.

## License
MIT